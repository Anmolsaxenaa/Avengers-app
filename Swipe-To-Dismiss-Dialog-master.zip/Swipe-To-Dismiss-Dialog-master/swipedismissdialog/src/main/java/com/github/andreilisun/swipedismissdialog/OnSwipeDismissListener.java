package com.github.andreilisun.swipedismissdialog;

import android.view.View;

public interface OnSwipeDismissListener {
    void onSwipeDismiss(View view, SwipeDismissDirection direction);
}
