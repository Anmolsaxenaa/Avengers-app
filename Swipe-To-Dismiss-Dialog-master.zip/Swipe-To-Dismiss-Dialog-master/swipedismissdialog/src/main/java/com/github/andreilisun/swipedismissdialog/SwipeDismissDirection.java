package com.github.andreilisun.swipedismissdialog;

public enum SwipeDismissDirection {
    LEFT, RIGHT, TOP, BOTTOM
}
