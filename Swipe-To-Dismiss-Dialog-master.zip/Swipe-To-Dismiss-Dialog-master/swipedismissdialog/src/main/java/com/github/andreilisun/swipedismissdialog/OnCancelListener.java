package com.github.andreilisun.swipedismissdialog;

import android.view.View;

public interface OnCancelListener {
    void onCancel(View view);
}
